??? python3 cmsfinder.py <ip> <puerto> ???
e24c582c76031aa3630682fddde541abb81331d19be46ad5df340b31cce87ab8  cmsfinder.py
7127c50080204d22f77d8fe6e249e6776771a95ab5aaa0d87ec866de9c573e97  cmslist.txt
8e69deaea32bbcd9c61a528331062af61520d8952c3ea5479f99064527289e31  urls_verificadas.txt

## Escáner de paneles de login de Content Managers (CMS):
## ajuste dinámico de round-to-trip (rtt).
## conexiones https por defecto, si error: http.
## indicios de páginas de login encontradas mediante status codes http (200 = OK),
## y mediante filtrado dinámico de contenido (palabras usuales).
## seguimiento de redirecciones hasta un número determinado de profundidad (5).
## errores ssl desactivados por defecto para una bonita visualización y veloces resultados.
## banderas "--errores" y "--debug" para mayor información.

@raulc0nes
#OpenAI
